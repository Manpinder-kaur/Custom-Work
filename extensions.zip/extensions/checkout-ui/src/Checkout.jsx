import {
  reactExtension,
  Banner,
  BlockStack,
  Checkbox,
  Text,
  useApi,
  useApplyAttributeChange,
  useInstructions,
  useTranslate,
  useExtensionApi,
  useSubscription,
  useApplyCartLinesChange,
  useCartLines
} from "@shopify/ui-extensions-react/checkout";
import { useEffect, useState } from 'react';
// 1. Choose an extension target
export default reactExtension("purchase.checkout.reductions.render-after", () => (
  <Extension />
));

function Extension() {
  const translate = useTranslate();
  const { extension } = useApi();
  const instructions = useInstructions();
  const applyCartLinesChange = useApplyCartLinesChange();
  const cartLines = useCartLines();
  const checkout = useExtensionApi();
  const { selectedPaymentOptions } = useExtensionApi();
  const _selectedPaymentOptions = useSubscription(selectedPaymentOptions);
  const [selectedPaymentMethodName, setSelectedPaymentMethodName] = useState('');
  const cost = checkout.cost;
  const subtotalAmount = cost.totalAmount.current.amount;

  const extracharge = (subtotalAmount * 0.5);

  const final_total = (subtotalAmount + extracharge);

  const paymentHandleMap = {
    'offsite-bda737431879e7dda387c6d9e86c0725': 'Tabby',
    'offsite-23dcb25873b3f403e1068f4bfb6a7126': 'Tamara',
    'direct-832fbdfe0cf115aed9d3b497dcb4cece': 'creditCard'
  };

  if (_selectedPaymentOptions[0].type == 'Tabby' || _selectedPaymentOptions[0].type == 'Tamara' || _selectedPaymentOptions[0].type == 'creditCard') {
    var isChecked = "yes";
    onCheckboxChange(isChecked);
  }
  else {
    var isChecked = "no";
    onCheckboxChange(isChecked);
  }

  // 3. Render a UI
  if (_selectedPaymentOptions[0].type == 'Tabby' || _selectedPaymentOptions[0].type == 'Tamara' || _selectedPaymentOptions[0].type == 'creditCard') {
    return (
      <Text>
        5% added in your order subtotal.
      </Text>
    );
  }

  async function onCheckboxChange(isChecked) {



    var index = 0;
    for (const line of cartLines) {

      if (index == 0) {
        var first_line = line;
        var check_attribute = first_line?.attributes[0]?.key;
        var attr_value = first_line?.attributes[0]?.value;
        if (check_attribute == "_extraFee" && isChecked == attr_value) {

        } else {
          applyCartLinesChange({
            type: "updateCartLine",
            id: first_line.id,
            attributes: [{
              key: '_extraFee',
              value: isChecked
            }]
          }).then((result) => {
            if (result.type === "error")
              console.error(result.message);
          });
        }
      }
      else {

        var check_attribute = line?.attributes[0]?.key;
        var attr_value = line?.attributes[0]?.value;
        if (check_attribute == "_extraFee" && attr_value == "no") {

        } else {
          applyCartLinesChange({
            type: "updateCartLine",
            id: line.id,
            attributes: [{
              key: '_extraFee',
              value: "no"
            }]
          }).then((result) => {
            if (result.type === "error")
              console.error(result.message);
          });
        }
      }


      index++;


    }
  }
}