import {
  DeliveryDiscountSelectionStrategy,
  DiscountClass,
} from "../generated/api";

/**
  * @typedef {import("../generated/api").DeliveryInput} RunInput
  * @typedef {import("../generated/api").CartDeliveryOptionsDiscountsGenerateRunResult} CartDeliveryOptionsDiscountsGenerateRunResult
  */

/**
  * @param {RunInput} input
  * @returns {CartDeliveryOptionsDiscountsGenerateRunResult}
  */

export function cartDeliveryOptionsDiscountsGenerateRun(input) {
  const firstDeliveryGroup = input.cart.deliveryGroups?.[0];
  if (!firstDeliveryGroup) {
    throw new Error("No delivery groups found");
  }

 
  const subtotal = Number(input.cart.cost?.subtotalAmount?.amount || 0);

  const shippingCost = Number(input.cart.attribute?.value || 0);

  if (subtotal < shippingCost) {
    return { operations: [] };
  }
 return {
    operations: [
      {
        deliveryDiscountsAdd: {
          candidates: [
            {
              message: "FREE DELIVERY",
              targets: [
                {
                  deliveryGroup: { id: firstDeliveryGroup.id },
                },
              ],
              value: {
                percentage: { value: 100 },
              },
            },
          ],
          selectionStrategy: DeliveryDiscountSelectionStrategy.All,
        },
      },
    ],
  };
}
