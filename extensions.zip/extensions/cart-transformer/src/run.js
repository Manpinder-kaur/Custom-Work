// @ts-check

/*
A straightforward example of a function that updates a line item title and price based on attributes.

The function reads the cart. Any item with a specific line item attribute will be used
to generate an update operation with a custom title, and price based on simple math using 
the line item attribute value.
*/

/**
 * @typedef {import("../generated/api").RunInput} RunInput
 * @typedef {import("../generated/api").FunctionRunResult} FunctionRunResult
 * @typedef {import("../generated/api").CartOperation} CartOperation
 */

/**
 * @type {FunctionRunResult}
 */
const NO_CHANGES = {
  operations: [],
};

/**
 * @param {RunInput} input
 * @returns {FunctionRunResult}
 */
export function run(input) {
  var totalAmt = 0;
  var finalSubTotal;
  input.cart.lines.forEach((amt) => {
    var main_amt = amt.cost.amountPerQuantity.amount;
    totalAmt = parseFloat(main_amt) + totalAmt;
    finalSubTotal = totalAmt.toFixed(2);
  });
  const operations = input.cart.lines.reduce(
    /** @param {CartOperation[]} acc */
    (acc, cartLine) => {
      const updateOperation = optionallyBuildUpdateOperation(cartLine, finalSubTotal);

      if (updateOperation) {
        return [...acc, { update: updateOperation }];
      }

      return acc;
    },
    []
  );

  return operations.length > 0 ? { operations } : NO_CHANGES;
};

/**
 * @param {RunInput['cart']['lines'][number]} cartLine
 */
function optionallyBuildUpdateOperation(
  { id: cartLineId, merchandise, cost, fabricLength }, finalSubTotal
) {
  const hasFabricLength = fabricLength;
  var priceAdjustmentAmount = 5;
  const subtotalPer = parseFloat(finalSubTotal) * 5 / 100;
  const originalPrice = parseFloat(cost.amountPerQuantity.amount);
  const newPrice = originalPrice + subtotalPer;

  if (
    merchandise.__typename === "ProductVariant" &&
    hasFabricLength?.value === "yes"
  ) {
    return {
      cartLineId,
      price: {
        adjustment: {
          fixedPricePerUnit: {
            amount: newPrice
          }
        }
      }
    };
  }

  return null;
}